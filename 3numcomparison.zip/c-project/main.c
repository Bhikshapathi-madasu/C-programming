#include <stdio.h>
int main() {
    int a,b,c;
    printf("enter a, b and c values:");
    scanf("%d%d%d",&a,&b,&c);
    if((b>a)&&(b>c)){
        printf("%d is greater then %d and %d ",b,a,c);
        
    }
    else if((a>b)&&(a>c))
    {
        printf("%d is greater then %d and %d",a,b,c);
    }
        else if((c>b)&&(c>a))
    {
        printf("%d is greater then %d and %d",c,a,b);
    }
       
    else 
    {
        printf("all values are equal:%d",a);
    } 
}
