#include <stdio.h>
int main() {
   int a;
    printf("enter a number:");
    scanf("%d",&a);
    if(a%2==0)
    {
        printf("%d a is even number",a);
        
    }
    else
    {
        printf("%d a is odd number",a);
    }
}
