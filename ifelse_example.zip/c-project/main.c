#include <stdio.h>
int main() {
    int balance=10000;
    int withdraw=15000;
    if(withdraw<=balance)
    {
         printf("withdraw successfully:");
         printf("%d",balance-withdraw);
    }
   else
    {
         printf("Insufficient balance");
    }
    return 0;
}
