#include <stdio.h>
int main() {
   char ch;
    printf("enter a character:");
        scanf("%c",&ch);
    if(ch=='a'||ch=='i'||ch=='e'||ch=='o'||ch=='u'||ch=='A'||ch=='E'||ch=='I'||ch=='o'||ch=='u')
    {
        printf("%c is a vowel",ch);
    }
    else
    {
        printf("%c is not a vowel",ch);
    }
}
