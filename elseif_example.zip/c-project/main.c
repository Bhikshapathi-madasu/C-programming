#include <stdio.h>
int main() {
    int a=10;
    int b=20;
    if(b>a){
        printf("b is greater then a ");
        
    }
    else if(a>b)
    {
        printf("a is greate then b");
    }
    else 
    {
        printf("both are equal");
    } 
}
